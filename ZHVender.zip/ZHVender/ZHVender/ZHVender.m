//
//  ZHVender.m
//  ZHVender
//
//  Created by 张晗 on 16/3/7.
//  Copyright © 2016年 kuangxiang. All rights reserved.
//

#import "ZHVender.h"

@implementation ZHVender

+ (void)printfSomethings{
    
    NSLog(@"this is a test file");
}

@end
